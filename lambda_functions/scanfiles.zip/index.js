const AWS = require('aws-sdk');
const S3 = new AWS.S3();

function haversineDistance(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // Earth's radius in meters
    const radLat1 = lat1 * Math.PI / 180;
    const radLat2 = lat2 * Math.PI / 180;
    const deltaLat = (lat2 - lat1) * Math.PI / 180;
    const deltaLon = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
              Math.cos(radLat1) * Math.cos(radLat2) * Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
}

function isUserInsideCircle(userPosition, filePosition, radius) {
    const distance = haversineDistance(
        userPosition.latitude,
        userPosition.longitude,
        filePosition.latitude,
        filePosition.longitude
    );

    return [(distance <= radius),distance];
}

exports.handler = async (event) => {
    console.log("Event received: ", event);
    const userPosition = {
        latitude: event.latitude,
        longitude: event.longitude,
    };

    const listParams = {
        Bucket: "location-based-file-share",
        Prefix: "uploads/",
    };

    try {
        const listResult = await S3.listObjectsV2(listParams).promise();
        const keys = listResult.Contents.map(content => content.Key);

        const availableFiles = [];

        for (const key of keys) {
            const getObjectParams = {
                Bucket: "location-based-file-share",
                Key: key,
            };

            const headObjectResult = await S3.headObject(getObjectParams).promise();
            const fileMetadata = headObjectResult.Metadata;
            const filePosition = {
                latitude: parseFloat(fileMetadata.latitude),
                longitude: parseFloat(fileMetadata.longitude),
            };
            
            const results = isUserInsideCircle(userPosition, filePosition, parseFloat(fileMetadata.radius))
            
            if (results[0]) {
                availableFiles.push([key.split('/').pop(),fileMetadata.filename,results[1]]);
            }
        }

        availableFiles.sort((x, y) => x.distance - y.distance);
        
        return {
            statusCode: 200,
            body: JSON.stringify(availableFiles),
        };
    } catch (error) {
        console.error("Error scanning files:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error scanning files" }),
        };
    }
};