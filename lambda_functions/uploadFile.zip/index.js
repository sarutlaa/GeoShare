const AWS = require('aws-sdk');
const S3 = new AWS.S3();
const crypto = require('crypto');

exports.handler = async (event) => {
    
    console.log("Event received");
    const body = JSON.parse(JSON.stringify(event));
    console.log("File name:", event.fileName);
    
    const fileName = body.fileName;
    const fileContent = body.fileContent;

    const buffer = Buffer.from(fileContent, 'base64');

    const fileId = crypto.randomBytes(16).toString('hex');
    const fileExtension = fileName.split('.').pop();
    const s3Key = `uploads/${fileId}.${fileExtension}`;

    const params = {
        Bucket: "location-based-file-share",
        Key: s3Key,
        Body: buffer,
        Metadata: {
            'filename': fileName,
            'mimeType': body.mimeType,
            'latitude': body.latitude.toString(),
            'longitude': body.longitude.toString(),
            'radius': body.radius.toString(),
        },
    };

    try {
        await S3.putObject(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "File uploaded successfully" }),
        };
    } catch (error) {
        console.error("Error uploading file:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error uploading file" }),
        };
    }
};
