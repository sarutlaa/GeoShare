const AWS = require('aws-sdk');
const S3 = new AWS.S3();

exports.handler = async (event) => {
    console.log("Event received: ", event);

    const listParams = {
        Bucket: "location-based-file-share",
        Prefix: "uploads/",
    };

    try {
        const listResult = await S3.listObjectsV2(listParams).promise();
        const keys = listResult.Contents.map(content => content.Key);

        // Create an array of promises for the headObject calls
        const headObjectPromises = keys.map(key => {
            const headObjectParams = {
                Bucket: "location-based-file-share",
                Key: key,
            };
            return S3.headObject(headObjectParams).promise();
        });

        // Wait for all the headObject calls to complete
        const headObjectResults = await Promise.all(headObjectPromises);

        // Process the results
        const availableFiles = headObjectResults.map((result, index) => {
            const fileMetadata = result.Metadata;
            const fileName = fileMetadata.filename || keys[index].replace('uploads/', '');
            return [
                parseFloat(fileMetadata.latitude),
                parseFloat(fileMetadata.longitude),
                parseFloat(fileMetadata.radius),
                fileName,
            ];
        });

        return {
            statusCode: 200,
            body: JSON.stringify(availableFiles),
        };
    } catch (error) {
        console.error("Error scanning files:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error scanning files" }),
        };
    }
};
