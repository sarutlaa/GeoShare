const AWS = require('aws-sdk');
const S3 = new AWS.S3();

exports.handler = async (event) => {
    const fileName = event.fileName;

    const deleteObjectParams = {
        Bucket: "location-based-file-share",
        Key: `uploads/${fileName}`,
    };

    try {
        await S3.deleteObject(deleteObjectParams).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "File deleted successfully" }),
        };
    } catch (error) {
        console.error("Error deleting file:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error deleting file" }),
        };
    }
};
