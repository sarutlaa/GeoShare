const AWS = require('aws-sdk');
const S3 = new AWS.S3();

exports.handler = async (event) => {
    console.log("Event received: ", event);
    const fileName = event.fileName;

    const getObjectParams = {
        Bucket: "location-based-file-share",
        Key: `uploads/${fileName}`,
    };

    try {
        const getObjectResult = await S3.getObject(getObjectParams).promise();
        const fileContent = getObjectResult.Body;
        const fileMetadata = getObjectResult.Metadata;
        const mimeType = fileMetadata.mimetype;

        const base64FileContent = fileContent.toString('base64');
        const result = {
            fileName: fileName,
            mimeType: mimeType,
            fileContent: base64FileContent,
        };

        return {
            statusCode: 200,
            body: JSON.stringify(result),
        };
    } catch (error) {
        console.error("Error downloading file:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error downloading file" }),
        };
    }
};
